from dateutil import parser
import datetime

from copy import deepcopy
import ast


class Parser:
    def __init__(self):
        self.type_mapping = {
            str: "string",
            int: "int",
            float: "float",
            datetime.datetime: "datetime",
            datetime.date: "date",
            type(None): "string"
        }

    def check_date_type(self, dt):
        """
        :param dt: '2018-01-01'
        :return: type
        """
        dt_len = len(dt)

        if dt_len > 10:
            return datetime.datetime
        else:
            return datetime.date

    def return_type(self, e):
        val = deepcopy(e)

        val = val.strip()

        symbols = ['$', '%', '&']

        if val == '':
            return str

        for i in symbols:
            if i in val:
                return str

        try:
            print("trying")
            token = ast.literal_eval(val)
        except SyntaxError:
            print(type(val))
            print(repr(val))
            print("Catching Syntax Error")
            try:
                token = parser.parse(val)
                print("Token =>", token)
                if isinstance(token, datetime.datetime):
                    return self.check_date_type(e)
            except ValueError:
                token = str(val)
        except ValueError:
            print("Catching Value Error")
            token = str(val)
        return type(token)

    def col_mappings(self, schema):
        col_dtypes = {}

        for item in schema:
            for index, j in enumerate(item, start=1):
                val = self.return_type(j)
                if index not in col_dtypes:
                    col_dtypes[index] = {}

                if val not in col_dtypes[index]:
                    col_dtypes[index][val] = 1
                else:
                    col_dtypes[index][val] += 1
        return col_dtypes

    def parse_cols(self, cols):
        dd = {}
        for col, value in cols.items():
            if str in value.keys():
                dd[col] = self.type_mapping.get(str)
            elif datetime.datetime in value.keys() and (float in value.keys() or int in value.keys()):
                dd[col] = self.type_mapping.get(str)
            elif datetime.date in value.keys() and (float in value.keys() or int in value.keys()):
                dd[col] = self.type_mapping.get(str)
            elif float in value.keys():
                dd[col] = self.type_mapping.get(float)
            elif datetime.datetime in value.keys() and datetime.date in value.keys():
                dd[col] = self.type_mapping.get(datetime.datetime)
            else:
                dd[col] = self.type_mapping.get(list(value.keys())[0])
        return dd

    def get_infered_schema(self, schema_list, dtypes):
        infered_schema = []
        for schema in schema_list:
            col_pos = schema["position"]
            dtype_val = dtypes[col_pos]
            if dtype_val == 'int' or dtype_val == 'float':
                dtype_val = 'numeric'
                schema["sum"] = True
                schema["min"] = True
                schema["max"] = True
                schema['mean'] = True
                schema['median'] = True
                schema['std_dev'] = True
                schema["format"] = "_.##"

            if dtype_val == 'date':
                schema["group_by"] = True
                schema["format"] = "DD-MM-YYYY"

            if dtype_val == 'datetime':
                schema["group_by"] = True
                schema["format"] = "YYYY-MM-DD HH:MI:SS"

            if dtype_val == 'string':
                schema["format"] = 'string'
                schema["group_by"] = True

            schema["datatype"] = dtype_val
            infered_schema.append(schema)
        return infered_schema

    def infer_data_types(self, schema_list, preview_data):
        mappings = self.col_mappings(preview_data)
        parse = self.parse_cols(mappings)
        infered_schema = self.get_infered_schema(schema_list, parse)

        return infered_schema
