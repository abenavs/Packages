import pandas as pd
import numpy as np
from fbprophet import Prophet
import datetime
from utils import input_data
from dateutil.relativedelta import *
from utils.log_util import log




# cluster = LocalCluster()
# client = Client(cluster)

class Forecasting:
    def __init__(self, dataset_path, dependent_metric, period , frequency , actual_date ,output_folder,transposed_actuals,transposed,user_id,dataset_id):
        '''
        :param hdf5_path: Path of the dataset
        :param table_name: Dataset name
        :param catalog: catalog contains information of the columns and values in dataset
        :param dependent_metric: The output variable metric
        :param choosen_dim: The dimension choosen from the user
        :param include_filter: Date filter and value filters
        '''
        self.dataset = dataset_path
        self.dependent_metric = dependent_metric
        self.period = period
        self.frequency = frequency
        self.actual_date = actual_date
        self.output_folder = output_folder
        self.date = ""
        self.transposed_actuals = transposed_actuals
        self.transposed = transposed
        self.input = input_data.InputDataFile()
        self.user_id = user_id
        self.dataset_id = dataset_id

    def resampling_data(self):
        '''
        Resampling the orginal data by groupby for the given metric

        '''
        # data = pd.read_csv(self.dataset, index_col=0)

        try:
            data = self.dataset
            new_data = data[self.dependent_metric].resample(self.frequency).sum()

        except Exception as e:
            log('----------Error in Resampling Data function ----------:{}'.format(e), 'error')
            raise e

        return new_data

    def clean_ts(self):
        """
        takes time series as input and returns cleaned time series

        *removes outliers
        *linearly interpolates missing values

        returns time series back
        """
        try:
            ts = self.resampling_data()
            # find the start of the time series
            start_ts = ts[ts.notna()].index[0]
            # find the end of the time series
            end_ts = ts[ts.notna()].index[-1]
            ts = ts.loc[start_ts:end_ts]

            # sets outliers to NaN defined as a point that is 3 deviations away from rolling mean + 3*rolling standard deviation
            ts = ts.where(~(abs(ts) > (ts.rolling(center=False, window=3).mean() + (
                        ts.rolling(center=False, window=3, min_periods=3).std() * 3))), np.nan)
            # linearly interpolate any NaN values
            ts = ts.interpolate()
            # make sure any remaining null values are filled with 0's
            ts = ts.fillna(0)


        except Exception as e:
            log('----------Error in Clean_ts function ----------:{}'.format(e), 'error')
            raise e

        return ts

    def forecast_prophet(self, ts):
        """forecasts a time series object using FB prophet model (https://facebook.github.io/prophet/)
        Note: forecast_ts returns fitted period values as well as forecasted period values

        if return_df is True need to get results like this:

            tseries, prophet_model, forc_df = forecast_prophet(df['series1'],return_df=True)

            Args:
                ts: time series object
                forecast_periods: periods to forecast for
                changepoint_prior_scale: changepoint value (lower value means trend is more flexible, easier to change)
                freq: frequency of the data ('MS' is Monthly Start could use M for month end)
                return_df: if set to true, returns full forecast dataframe with upper and lower values

            Returns: of f
                 forecast_ts: time seriesitted and forecasted values
                 forecast_df: full forecast dataframe to be used for plotting or for upper/lower conf interval values
                 model: prophet fitted model

        """
        try:
            forecast_periods = self.period
            changepoint_prior_scale = .05
            freq = self.frequency
            return_df = False
            # find the start of the time series
            start_ts = ts[ts.notna()].index[0]
            # find the end of the time series
            end_ts = ts[ts.notna()].index[-1]
            # extract actual time series
            ts = ts.loc[start_ts:end_ts]

            model_ts = ts.reset_index()
            model_ts.columns = ['ds', 'y']

            model = Prophet(changepoint_prior_scale=changepoint_prior_scale)
            model.fit(model_ts)

            future = model.make_future_dataframe(periods=forecast_periods, freq=freq)
            forecast_df = model.predict(future)

            forecast_ts = forecast_df.set_index('ds')['yhat']

            # date range is min of current series to max of all series (we'll filter out dataframe of series we dont want eventually so that we dont have to do this)

            if return_df == False:
                return forecast_ts
        except Exception as e:
            log('----------Error in Forecast_Prophet function ----------:{}'.format(e), 'error')
            raise e

        return forecast_ts

    def data_manupulation(self):
        '''
        Storing the predicted result in a csv format
        '''
        # output_fc = []
        # data = self.clean_ts()
        # forecasted_series = dask.delayed(self.forecast_prophet)(data)
        # output_fc.append(forecasted_series)

        # total = dask.delayed(output_fc).compute()
        try:
            data = self.clean_ts()

            data.to_csv("{}/actuals_out.csv".format(self.output_folder),header=['Actuals'])

            tseries = self.forecast_prophet(data)

            '''Converting the series data to dataframe with header predicted and storing in the r_outputs folder'''
            tseries.to_csv("{}/pred_out.csv".format(self.output_folder), header = ['Predicted'])
            predicted_result = pd.read_csv("{}/pred_out.csv".format(self.output_folder))

        except Exception as e:
            log('----------Error in Data manipulation function ----------:{}'.format(e), 'error')
            raise e

        return predicted_result

    def data_ratio_data(self):
        '''
        getting the actual sum of the last row of the actual data to get the ratio
        '''
        try:
            predicted_result = self.data_manupulation()
            combination_data = self.transposed_actuals
            self.date = self.check_dates()
            last_row_actual = combination_data.loc[combination_data['Month'] == self.date]
            last_row_actual = last_row_actual.iloc[-1].tolist()
            total_sum_actual = sum(last_row_actual[1:])

        except Exception as e:
            log('----------Error in data_ratio_data function ----------:{}'.format(e), 'error')
            raise e
        return total_sum_actual, last_row_actual[1:], predicted_result

    def find_ratios_actual(self):
        '''
        Getting the actual ratio from the actual data
        '''
        try:
            total_sum_actual, last_row_actual, predicted_result = self.data_ratio_data()
            output_ratio = list(map(lambda x: x / total_sum_actual, last_row_actual))
        except Exception as e:
            log('----------Error in find_ratios_Actual function ----------:{}'.format(e), 'error')
            raise e

        return output_ratio, predicted_result

    def making_ratios(self):
        '''
        With the actual ratios we split the forecasted sum
        '''
        try:
            output_ratio, predicted_result = self.find_ratios_actual()

            df = predicted_result.loc[predicted_result['ds'] == datetime.datetime.strftime(self.actual_date,"%Y-%m-%d")]

            last_row_predicted = df.iloc[-1].tolist()

            sum_row_predicted = last_row_predicted[1]

            last_predicted_ratio = self.ratios_actual(output_ratio, sum_row_predicted)

        except Exception as e:
            log('----------Error in making_ratios function ----------:{}'.format(e), 'error')
            raise e

        return last_predicted_ratio, output_ratio, predicted_result

    def replacing_ratios(self):
        '''
        Replacing the predicted ratio to the series dataset
        '''
        try:
            last_predicted_ratio, output_ratio, predicted_result = self.making_ratios()
            series = self.making_series_dataframe()
            series.loc[str(self.actual_date)] = last_predicted_ratio

        except Exception as e:
            log('----------Error in replacing_ratios function ----------:{}'.format(e), 'error')
            raise e

        return series, output_ratio, predicted_result

    def making_all_ratios(self):
        '''
        Assigning the result to the nan values
        '''
        try:
            series, output_ratio, predicted_result = self.replacing_ratios()
            list_dates = self.getting_dates(series)

            for i in list_dates:
                sum_row_predicted = self.getting_predicted_value(predicted_result,i)
                series.loc[i] = self.ratios_actual(output_ratio, sum_row_predicted)
        except Exception as e:
            log('----------Error in making_all_ratios function ----------:{}'.format(e), 'error')
            raise e

        return series

    def final_result(self):
        try:
            series = self.making_all_ratios()
            # series.to_hdf(self.output_folder + "transposed_otp.h5",key="transposed_otp",mode="w")
            self.input.save_output_to_hdf(user_id=self.user_id,table_name="transposed_otp",data=series,dataset_id=self.dataset_id)
        except Exception as e:
            log('----------Error in Forecast Process ----------:{}'.format(e), 'error')
            raise e

        return series

    # def forecast_ratios(self):
    #     output_list, predicted_result = self.find_ratios_actual()
    #     last_row_actual = self.making_ratios()


    def ratios_actual(self, output, total_sum):
        try:
            output_ratio = list(map(lambda x: x * total_sum, output))
        except Exception as e:
            log('----------Error in ratios_actual function ----------:{}'.format(e), 'error')
            raise e

        return output_ratio


    def making_series_dataframe(self):
        try:
            series = self.transposed
        except Exception as e:
            log('----------Error in making_series_dataframe function ----------:{}'.format(e), 'error')
            raise e

        return series


    def getting_predicted_value(self, predicted_result, date):
        try:
            df = predicted_result.loc[predicted_result["ds"] == str(date)]
            last_row_predicted = df.iloc[-1].tolist()
            sum_row_predicted = last_row_predicted[1]

        except Exception as e:
            log('----------Error in getting_predicted_value function ----------:{}'.format(e), 'error')
            raise e
        return sum_row_predicted

    def getting_dates(self, series):
        try:
            we = pd.isnull(series).any(1).nonzero()[0]
            output_ratio = list(map(lambda x: series.index[x], we))

        except Exception as e:
            log('----------Error in getting_dates function ----------:{}'.format(e), 'error')
            raise e

        return output_ratio

    def check_dates(self):
        '''
        Checking for 'Month', 'Day' and 'Week' and assigning to the model for prediction and forecast
        '''
        try:
            today = datetime.datetime.strptime(str(self.actual_date), "%Y-%m-%d").date()
            if str(self.frequency) == 'D':
                last_monday = today - relativedelta(days=7)
            elif str(self.frequency) == 'MS':
                last_monday = today - relativedelta(months=1)
            elif str(self.frequency) == 'W':
                last_monday = today - relativedelta(weeks=1)
            elif str(self.frequency) == 'Q':
                last_monday = today - relativedelta(months=3)
            elif str(self.frequency) == 'Y':
                last_monday = today - relativedelta(years=1)
            date = last_monday.strftime("%Y-%m-%d")
        except Exception as e:
            log('----------Error in check_Dates function ----------:{}'.format(e), 'error')
            raise e

        return date









