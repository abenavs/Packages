import os
abs_file_path = os.path.abspath("../")
print(abs_file_path)
import pandas as pd

'''
Global variables are referenced from this class. This class is passed as argument to develop and production functions.
'''

class glb_var:

    #prod
    output_folder = os.path.abspath("../") + '/r_outputs/'
    input_path = os.path.abspath("../../../../") + '/spotcast_datastore/csv_files/'

    #dev
    # output_folder = os.path.abspath("../../") +'/spotcast/r_outputs/'
    # input_path = os.path.abspath("../../../") +'/spotcast_datastore/csv_files/'

    R_Script = 'Rscript'
    path = abs_file_path
    log_path = abs_file_path + '/logs/'


    fs = 12 # "Monthly:12;Bimonthly:24;Quaterly:4;Weekly:52,Yearly:365
    Int_id_col = 'dim_id' #assigning from input data
    Int_metric_col_prev = "metric" + '_prev_week'  #assigning from input data


class Development(glb_var):

    def __init__(self):
        pass


class Production(glb_var):

    def __init__(self):
        pass


glb_var = {
    'development': Development,
    'production': Production
}