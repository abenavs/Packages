from flask import current_app

def log(message, level=None):
    if level is None:
        current_app.logger.warning(message)

    if level == "debug":
        current_app.logger.debug(message)

    if level == "info":
        current_app.logger.info(message)

    if level == "warning":
        current_app.logger.warning(message)

    if level == "error":
        current_app.logger.error(message)

    if level == "critical":
        current_app.logger.critical(message)
