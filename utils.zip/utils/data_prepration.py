import pandas as pd
import re
import json

class DataPreparation:

    def get_dim_met(self, dataframe):
        """ Seperate dimensions and metrics columns and display the unique values
        Input :  Original dataset in csv format
        Output : Unique Values of each column sorted based on the count of the distinct value
        """
        dim_dic, uniq_dic, dim = dict(), dict(), dict()
        sort_lst, dimensions, date, metrics = list(), list(), list(), list()
        df = dataframe.head(10)
        for each in dataframe.columns:
            if dataframe[each].dtypes == "object" or dataframe[each].dtypes == "datetime64":
                try:
                    df[each] = pd.to_datetime(df[each])
                    val = {'name': each, 'type': 'datetime64', 'distinct': len(df[each].unique())}
                    date.append(val)
                except ValueError:
                    d = {each: len(df[each].unique())}
                    dim_dic.update(d)
            elif dataframe[each].dtypes == "int64" or dataframe[
                each].dtypes == "float64" or dataframe[each].dtypes == "int32" or dataframe[each].dtypes == "float32":
                val = {'name': each, 'type': 'numeric', 'distinct': len(df[each].unique())}
                metrics.append(val)
        for key, value in sorted(dim_dic.items(), key=lambda item: item[1]):
            sort_lst.append(key)

        dimensions = sort_lst
        for i in dimensions:
            cleanedList = [x for x in list(df[i].unique()) if str(x) != 'nan']
            uniq = {i: cleanedList}
            uniq_dic.update(uniq)
        dim["dim_distinct"] = dimensions
        dim["unique_values"] = uniq_dic
        datatype = {'dimensions': dim, 'date': date, 'metrics': metrics}

        return self.prioritize_dim(datatype)

    def get_dimensions_metrics(self, dataframe):
        """ Seperate dimensions and metrics columns and display the unique values
        Input :  Original dataset in csv format
        Output : Unique Values of each column sorted based on the count of the distinct value of each column
        """
    
        dim_dic, uniq_dic = dict(), dict()
        sort_lst, dimensions, date, metrics = list(), list(), list(), list()
        df = dataframe.head(10)
        for each in dataframe.columns:
            if dataframe[each].dtypes == "object" or dataframe[each].dtypes == "datetime64":
                try:
                    df[each] = pd.to_datetime(df[each])
                    val = {'name': each, 'type': 'datetime64', 'distinct': len(df[each].unique())}
                    date.append(val)
                except ValueError:
                    val = {'name': each, 'type': 'object', 'distinct': len(df[each].unique()),
                           'unique_values': [x for x in self.sorted_nicely(l=list(dataframe[each].unique())) if str(x) != 'nan']}
                    dimensions.append(val)

            elif dataframe[each].dtypes == "int64" or dataframe[
                each].dtypes == "float64" or dataframe[each].dtypes == "int32" or dataframe[
                each].dtypes == "float32":
                val = {'dimension_name': each, 'dimension_type': 'numeric','distinct': len(df[each].unique())}
                metrics.append(val)

            datatype = {'dimensions': dimensions, 'date': date, 'metrics': metrics}

        return self.prioritize(datatype)

    def sorted_nicely(self,l):
        """ Sorts the given iterable in the way that is expected.

        Required arguments:
        l -- The iterable to be sorted.

        """

        convert = lambda text: int(text) if text.isdigit() else text
        alphanum_key = lambda key: [convert(c) for c in re.split('([0-9]+)', key)]
        return sorted(l, key=alphanum_key)


    def prioritize_dim(self,json):
        """ Reordering the metric values based on their unique values
        Input: List of Metric columns along with their unique values
        Output: Reordered Metric columns
        """
        datatype = json
        n = len(datatype['metrics'])
        for i in range(n):
            for j in range(0, n - i - 1):
                if datatype['metrics'][j + 1]['distinct'] > datatype['metrics'][j]['distinct']:
                    datatype['metrics'][j + 1], datatype['metrics'][j] = datatype['metrics'][j], datatype['metrics'][
                        j + 1]
                else:
                    pass

        return datatype

    def prioritize(self,json):
        """ Reordering the metric values based on their unique values
        Input: List of Metric columns along with their unique values
        Output: Reordered Metric columns
        """

        datatype = json
        n = len(datatype['dimensions'])
        for i in range(n):
            for j in range(0, n - i - 1):
                if datatype['dimensions'][j]['distinct'] > datatype['dimensions'][j + 1]['distinct']:
                    datatype['dimensions'][j + 1], datatype['dimensions'][j] = datatype['dimensions'][j], \
                                                                                datatype['dimensions'][j + 1]
                else:
                    pass
        n = len(datatype['metrics'])
        for i in range(n):
            for j in range(0, n - i - 1):
                if datatype['metrics'][j + 1]['distinct'] > datatype['metrics'][j]['distinct']:
                    datatype['metrics'][j + 1], datatype['metrics'][j] = datatype['metrics'][j], datatype['metrics'][
                        j + 1]
                else:
                    pass

        return datatype



    def is_metric_null(self ,dataframe ,metrics):
        """ Filling missing values in dataframe with mean
        Input: metric columns and the original data
        Output: Imputed metric columns with Mean
        """
        for each in metrics:
         #  for row in dataframe[each]:
            if dataframe.isnull():
                dataframe.fillna(value=dataframe.loc[: ,each].mean())
        return dataframe

