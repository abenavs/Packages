class DateFormatParser:
    def __init__(self):
        self.excel_to_pd_tuple = [
            ('ddd', '%a'),  # Abbreviated day of the week.
            ('dddd', '%A'),  # Full day of the week.
            ('w', '%w'),  # Weekday as a decimal number, 0 to 6, Sunday is 0.
            ('dd', '%d'),  # Day of the month as a zero-padded decimal number.
            # ('d', '%-d'), # Not supported in Python.
            ('mmm', '%b'),  # Month as locale’s abbreviated name.
            ('mmmm', '%B'),  # Month as locale’s full name.
            ('mm', '%m'),
            # ('m', '%-m'), # Not supported in Python.
            ('yy', '%y'),  # Year without century as a zero-padded decimal numbe
            ('yyyy', '%Y'),  # Year with century as a decimal number.
            ('HH', '%H'),  # Hour (24-hour clock) as a zero-padded decimal number.
            # ('H', '%-H'), # Not supported in Python.
            ('hh', '%I'),  # Hour (12-hour clock) as a zero-padded decimal number.
            # ('h', '%-I'),  # Not supported in Python.
            ('P', '%p'),  # Locale’s equivalent of either AM or PM.
            ('MM', '%M'),  # Minute as a zero-padded decimal number.
            # ('M', '%-M'), # Not supported in Python.
            ('SS', '%S'),  # Second as a zero-padded decimal number.
            # ('S', '%-S'), # Not supported in Python.
            ('f', '%f'),  # Microsecond as a decimal number, zero-padded on the left.
            ('z', '%z'),  # UTC offset in the form +HHMM or -HHMM (empty string if the the object is naive).
            ('Z', '%Z'),  # Time zone name (empty string if the object is naive).
            ('jj', '%j'),  # Day of the year as a zero-padded decimal number.
            # ('j', '%-j'), # Not supported in Python.
            ('U', '%U'),
            # Week number of the year (Sunday as the first day of the week) as a zero padded decimal number. All days in a new year preceding the first Sunday are considered to be in week 0.
            ('W', '%W'),
            # Week number of the year (Monday as the first day of the week) as a decimal number. All days in a new year preceding the first Monday are considered to be in week 0.
        ]


    def map_input_to_pd_tups(self, input_format):
        result = []
        sorted_tups = sorted(self.excel_to_pd_tuple, key=lambda t: len(t[0]), reverse=True)
        for e, p in sorted_tups:
            idx = input_format.find(e)
            if idx >= 0:
                result.append((p, idx, idx + len(e) - 1))
                replace_str = '`' * len(e)
                input_format = input_format.replace(e, replace_str)

        return sorted(result, key=lambda t: t[1])

    def get_pd_format(self, input_format):
        sorted_tups = self.map_input_to_pd_tups(input_format)
        prev_e = -1
        result = []
        for f, s, e in sorted_tups:
            result.append(input_format[prev_e + 1:s])
            result.append(f)
            prev_e = e

        result.append(input_format[e + 1: len(input_format)])

        return "".join(result)
