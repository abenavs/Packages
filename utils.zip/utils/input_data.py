import os
abs_file_path = os.path.abspath("./")
import pandas as pd
from datetime import datetime,timedelta
from utils.glb_var import glb_var as gb
import itertools as it
import numpy as np
import logging
from pathlib import Path
from dateutil.relativedelta import *
from utils.modelling import Forecasting
from utils.log_util import log

class InputDataFile():

    def __init__(self, env="production"):
        '''
        Global variables are referenced here from the prod environment
        '''
        self.default_gb = gb[env]()
        self.output_folder = self.default_gb.output_folder
        self.Int_id_col = self.default_gb.Int_id_col
        self.Int_metric_col_prev = self.default_gb.Int_metric_col_prev

    def save_output_to_hdf(self,user_id, table_name, data,dataset_id):
        '''
        Save Output files to hdf files in local system if the file exists in hdf5 format in the datastore
        Input: Table, dataset(csv),dataset_id
        Output: output file in hdf5
        '''
        try:
            basedir = str(Path.home())
            output_storage = "spotcast_datastore/output_files/user_{user_id}/{dataset_id}".format(user_id=user_id,dataset_id=dataset_id)
            datastore = "user_{user_id}.h5".format(user_id=user_id)

            hdf_path = os.path.join("{}/{}".format(basedir,output_storage))

            if os.path.isdir(hdf_path) is False:
                self.create_file_directory(hdf_path)

            if not self.check_if_file_exists(
                    "{hdf_path}/{hdf_store_name}".format(hdf_path=hdf_path, hdf_store_name=datastore)):

                hdf = pd.HDFStore(
                    "{hdf_path}/{hdf_store_name}".format(hdf_path=hdf_path, hdf_store_name=datastore))
                hdf.put(table_name, data, format='table',
                        data_columns=True, index=None)
                hdf.close()
            else:

                data.to_hdf("{hdf_path}/{hdf_store_name}".format(hdf_path=hdf_path, hdf_store_name=datastore),
                            table_name,index=None)
            return True
        except Exception as e:
            print("Exception while saving data-to-hdf")
            return False

    def create_file_directory(self,path):
        if not os.path.exists(path):
            os.makedirs(path)
            print("Directory ", path, " Created ")
        else:
            print("Directory ", path, " Already Exists")

    def check_if_file_exists(self,file_path):
        if os.path.exists(file_path):
            return True
        else:
            return False

    def input_data(self, data,met,date,dimension_list):
        '''
        Creates an input data stream with all possible combinations of groupby and sum operation applied on list of dimensions
        Input : dataset in csv, metric to sum, dimensions_list to group by, date to subset data
        Output : dataframe with possible combinations of grouped by dimension values
        '''
        logging.info("Path : " + str(data))
        try:
            dimension = dimension_list
            dimension.append(date)
            result = pd.DataFrame()
            subset_list = [list(subset) for i in range(0, len(dimension) + 1) for subset in it.combinations(dimension, i)]
            x2 = [data.groupby(subset)[met].sum() for subset in subset_list  if len(subset) > 0] # grouping by subset of all possible combinations with sales
            x3 = [x.to_frame().reset_index() for x in x2 ] # resetting index old index as columns and new index as index
            for x in x3:# concatinating empty df with x2
                result = pd.concat([result, x], axis=0, sort=False)
            result = result.dropna(subset=[date])
            logging.info(result)
            result = result.dropna() #drop NA
            log('----------Created Dataframe with all possible combinations----------', 'info')

            return result
        except Exception as e:
            log('----------Error in Input Data Function----------:{}'.format(e), 'error')

    def make_identifier(self, df):
        '''
        Extracts identifier column from the dataset as combination of first and second columns
        Input : Data in csv
        Output : unique identifier column values
        '''
        logging.info("df : " + str(df))
        try:
            col_list = list(df.columns)
            string_id = df[col_list[0]].str.cat(df[col_list[1:]], sep="_")
            return pd.factorize(string_id)[0]  # --FACTORIZING WITH A NUMBER- FIND unique values
        except Exception as e:
            log('----------Error in creating identifiers----------:{}'.format(e), 'error')

    def combination(self, results,met,date,dimension,user_id,dataset_id):
        '''
        Extracts identifier column from the dataset as combination of first and second columns
        Input : Data in csv
        Output : unique identifier column values
        '''

        try:
            results[self.Int_id_col] = self.make_identifier(results[dimension]) + 1  # CREATING DIM_ID IN RESULT WITH ONLY STRING COLUMNS FROM FULL DATA
            # To create nodes for later usage
            nodes = results.drop([date,met], axis=1).drop_duplicates()

            # To get the nodes in the desired format
            self.save_output_to_hdf(user_id=user_id,table_name="nodes",data=nodes,dataset_id=dataset_id)

            # To create connections for later usage
            result = results[[self.Int_id_col, date,met]]
            self.save_output_to_hdf(user_id=user_id,table_name="cube",data=result,dataset_id=dataset_id)
            log('----------Node and Cube dataframes saved to hdf file----------','info')

            return result
        except Exception as e:
            log('----------Error in Combination Function----------:{}'.format(e), 'error')

    def data_preparation(self,met,date, period,cube,user_id,dataset_id):
        '''
        Extracts identifier column from the dataset as combination of first and second columns
        Input : Data in csv
        Output : unique identifier column values
        '''
        try:
            dataset = cube
            tp_data = dataset.pivot(index= date, columns=self.Int_id_col, values=met) #Reshapes data
            tp_data["date_index"] = pd.to_datetime(tp_data.index)
            # if resample_flag == 1:
            #     tp_data_ = tp_data.resample(period[0],on="date_index").sum()
            #     tp_data_["date_index"] = tp_data_.index.date
            # else:
            tp_data['date_index'] = tp_data['date_index'].dt.date
            tp_data_ = tp_data.sort_values(by="date_index")
            tp_data_ = tp_data_.fillna(0)
            actuals = tp_data_.iloc[len(tp_data_)-2:]
            actuals = actuals.transpose()
            actuals.columns = [self.Int_metric_col_prev, met]
            actuals = actuals[[met, self.Int_metric_col_prev]]
            self.save_output_to_hdf(user_id=user_id,table_name="actuals",data=actuals,dataset_id=dataset_id)
            tp_data_=tp_data_.set_index(tp_data_["date_index"]) #set data index using date_index column

            if period[0] == 'MS':
                range = 12
            elif period[0] == 'D':
                range = 28
            elif period[0] == 'W':
                range = 7
            elif period[0] == 'Q':
                range = 4
            elif period[0] == 'Y':
                range = 4

            ini_time_for_now = tp_data_["date_index"].iloc[-1]
            dates = list()
            dates.append(ini_time_for_now)
            for i in dates:
                if period[0] == 'MS':
                    date_range = i + relativedelta(months=+1)
                elif period[0] == 'D':
                    date_range = i + relativedelta(days=+1)
                elif period[0] == 'W':
                    date_range = i + relativedelta(weeks=+1)
                elif period[0] == 'Q':
                    date_range = i + relativedelta(months=+3)
                elif period[0] == 'Y':
                    date_range = i + relativedelta(years=+1)
                dates.append(date_range)
                if len(dates) > range:
                    break
                else:
                    continue
            dates.pop(0)
            df = pd.DataFrame(dates)
            dateappend = tp_data_["date_index"].append(df, ignore_index=False)
            data = tp_data_.join(dateappend, how="outer")
            data=data.sort_values(by="date_index")
            data=data.drop(columns=['date_index'])
            tp_data_ = data.set_axis([*data.columns[:-1], 'Month'], axis=1, inplace=False)
            conv_dates = [date_obj.strftime('%Y-%m-%d') for date_obj in tp_data_['Month']]
            tp_data_['Month'] = conv_dates
            tp_data_=tp_data_.set_index(tp_data_['Month'])
            tp_data_1=tp_data_.drop(columns=['Month'])
            val=range+1
            transposed = tp_data_1.copy()
            tp_data_1.reset_index(inplace = True)
            self.save_output_to_hdf(user_id=user_id,table_name="transposed_actuals",data=tp_data_1,dataset_id=dataset_id)
            transposed.iloc[len(tp_data_1) - val ] = np.NaN
            self.save_output_to_hdf(user_id=user_id,table_name="transposed",data=transposed,dataset_id=dataset_id)
            logging.info('Data Processed and written')
            log('----------Transposed dataframe saved to hdf file----------','info')
            return val,ini_time_for_now,tp_data_1,transposed

        except Exception as e:
            log('----------Error in Data preparation----------:{}'.format(e), 'error')

    def process(self,dimension_metric, metric, date, period,dataset_id,user_id):

        log('------Input Data Processing Started--------','info')
        dimensions, metrics, date_col, datasetname, file_path = dimension_metric(dataset_id=dataset_id)
        data_ = self.input_data(data=pd.read_csv('{}'.format(file_path)), met=metric, date=date,
                dimension_list=dimensions[:3])
        cube_dataset  = self.combination(results = data_,met=metric,date=date,dimension=dimensions[:3],user_id=user_id,dataset_id=dataset_id)
        value,actual_date,transposed_actuals ,transposed= self.data_preparation(met=metric,date=date, period=period,cube=cube_dataset,user_id=user_id,dataset_id=dataset_id)
        log('-------Input Data Processed and Done---------','info')
        return value,actual_date,transposed_actuals,transposed


if __name__ == '__main__':

    inputdata = InputDataFile()
    inputdata.process()

