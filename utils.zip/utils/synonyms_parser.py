import inflect
class SynonymsParser:
    def __init__(self):
        self.synonyms = [
            ["cust", "customer", "customers"],
            ["prod", "product", "products"],
            ["id", "ID"],
            ["dt", "date", "week"],
            ["dt_time", "date", "time"],
            ["yr", "year", "years"],
            ["mth", "month", "months"],
            ["usr", "user", "users"],
            ["txn", "transaction", "txns"],
            ["nbr", "number", "no"],
            ["acct", "accounts", "account"],
            ["dim", "dimension", "dimensions"],
            ["acctg", "accounting"],
            ["inv", "invoice", "invoices"],
            ["org", "organization", "organizations"],
            ["ap", "accounts", "payable", "payables"],
            ["ar", "accounts", "receivable", "receivables"],
            ["acrl", "accural"],
            ["acum", "accumulative", "accumulation"],
            ["acq", "acquisition", "acquisitions"],
            ["addr", "address"],
            ["add", "add", "addition"],
            ["agi", "adjusted gross income", "gross income", "income"],
            ["agcy", "agency", "agencies"]
        ]

    def p(self, w):
        return "'{}'".format(w)

    def find_word(self, w):
        w = w.lower()
        engine = inflect.engine()
        plural = engine.plural(w)

        return plural.title()



    # def string_to_title_case(self, str):
    #     return ''.join(x for x in str.title() if not x.isspace())