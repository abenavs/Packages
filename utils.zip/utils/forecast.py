import os
abs_file_path = os.path.abspath("./")
from utils.glb_var import glb_var as gb
import pandas as pd
import json
from utils import input_data
from utils.modelling import Forecasting
from datetime import datetime
from utils.log_util import log
import subprocess
import pyRserve as rs
import logging# is a library connecting python to r

class Forecast():# this approach need to be implemented in all process

    def __init__(self, env="production"):
        """
        Reads variables from the global environment 
        """
        self.default_gb = gb[env]()
        self.output_folder = self.default_gb.output_folder
        self.Int_id_col = self.default_gb.Int_id_col
        self.Int_metric_col_prev = self.default_gb.Int_metric_col_prev


    # def partitions(self,path,period):
    #
    #         logging.info("Path : " + str(path))
    #         retcode = subprocess.run(path)
    #         logging.info("Obtained a valid result R")
    #         # print(retcode.check_returncode())

    def insights(self,node,actuals,forecasted,val,met,actual_key,previous_key,actual_date,user_id,dataset_id):
        try:
            input = input_data.InputDataFile()
            transpose_ = pd.DataFrame(forecasted.transpose())
            transposed= transpose_[str(actual_date)]
            data = actuals[:-1]
            node[actual_key] = data[met]
            node[previous_key] = data[self.Int_metric_col_prev]
            node['Forecast'] = (transposed.iloc[0:]).values
            node[actual_key] = node[actual_key].astype(float)
            node[previous_key] = node[previous_key].astype(float)
            node['Forecast'] = node['Forecast'].astype(float)
            node.drop(columns=['dim_id'],inplace=True)
            node_index = node[(node[actual_key] == 0.0) & (node["Forecast"] == 0.0)].index
            node.drop(node_index,inplace=True)
            input.save_output_to_hdf(user_id=user_id,table_name="final_ds",data=node,dataset_id=dataset_id)
            log('----------Created Dataframe with Actual & Forecast values----------', 'info')

        except Exception as e:
            log('----------Error in Creating Final Dataframe----------: {}'.format(e), 'error')


    def lookup(self,s):
        """
        This is an extremely fast approach to datetime parsing.
        For large data, the same dates are often repeated. Rather than
        re-parse these, we store all unique dates, parse them, and
        use a lookup to convert all dates.
        """

        dates = {date: pd.to_datetime(date) for date in s.unique()}
        return s.map(dates)

    def process(self,dataset,metric,date,period,actual_key,previous_key,value,actual_date,transposed_actuals,transposed,user_id,output_folder_path,dataset_id):
        """
        Input: transposed dataset with combination of dimensions
        Output: Dataframe with actual and forecasted values 
        """
        try:
            dataset_path = dataset
            dataset_path[date] = self.lookup(dataset_path[date])
            dataset_path.set_index(date,inplace=True)

            log('----------Forecast Modelling - Started -----------', 'info')
            forecasting = Forecasting(dataset_path=dataset_path, dependent_metric=metric,
                                      period=value - 1,
                                      frequency=period[0], actual_date=actual_date, output_folder=output_folder_path,
                                      transposed_actuals=transposed_actuals, transposed=transposed,user_id=user_id,dataset_id=dataset_id)
            forecasting.final_result()
            log('----------Forecast Modelling - Done -----------', 'info')

            actuals = pd.read_hdf('{}/user_{user_id}.h5'.format(output_folder_path,user_id=user_id),"actuals")
            actuals.reset_index(inplace=True)
            nodes = pd.read_hdf('{}/user_{user_id}.h5'.format(output_folder_path,user_id=user_id),"nodes",index=False)
            nodes.reset_index(inplace=True)
            nodes = nodes.drop(columns=['index'])
            transposed_otp =  pd.read_hdf('{}/user_{user_id}.h5'.format(output_folder_path,user_id=user_id),"transposed_otp")
            self.insights(node=nodes,
                          actuals=actuals,
                          forecasted=transposed_otp,
                          val=value, met=metric, actual_key=actual_key, previous_key=previous_key,
                          actual_date=actual_date,user_id=user_id,dataset_id=dataset_id)

        except Exception as e:
            log('----------Error in Forecast Process ----------:{}'.format(e), 'error')

if __name__ == '__main__':

    forecast = Forecast()
    forecast.process()