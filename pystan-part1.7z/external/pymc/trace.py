# mock out pymc classes for now
MultiTrace = type(None)
