import logging
from .misc import *

logger = logging.getLogger('pystan')

logger.warning("This submodule contains experimental code, please use with caution")
